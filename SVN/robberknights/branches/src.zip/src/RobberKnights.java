/**
 * Group 5 Robber Knights Game
 *
 * The RobberKnights Class:
 *
 * The RobberKnights class starts the game by calling the BoardGame class, which runs the game. 
 * 
 */

class RobberKnights {
	public static void main(String[] args) {
		BoardGame play = new BoardGame();
	}
}