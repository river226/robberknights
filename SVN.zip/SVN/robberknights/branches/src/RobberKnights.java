/**
 * Group 5 Robber Knights Game
 *
 * Members: Jedidiah Johnson, Alex Sokol, Aaron Thrasher, Rebecca Rasmussen, Tony Dederich
 *
 * The RobberKnights Class:
 *
 * The RobberKnights class starts the game by calling the BoardGame class, which runs the game. 
 * 
 */

class RobberKnights {
	public static void main(String[] args) {
		GUI play = new GUI();
	}
}