import java.util.ArrayList;


public class RobberKnightsGame {

	int numPlayers;
	Player[] players;
	Board board;
	
	public RobberKnightsGame(int numPlayers){
		For(int playerNum = 0; playerNum < numPlayers; playerNum++){
			players[i] = new Player();
			
		}
		board = new Board(numPlayers);		
	}
}
